get();

setInterval(get, 2000);

function send() {
    var message = document.getElementById('text').value;
    var user_name = document.getElementById('chat_name').value;

    (async () => {
            var response = await fetch('chat.php', {
                method: 'post',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: `message=${user_name}: ${message}`
            });
            var answer = await response.json();
            if (answer.status === "ok") document.getElementById('text').value = "";
            if (answer.status === "error") document.getElementById('text').value = answer.error;
        }
    )();
    document.getElementById('text').value = '';
}

function get() {

    (async () => {
            var response = await fetch('chat.php');
            var answer = await response.json();
            let str = '';
            for (i in answer.messages) {
                str = str + `<div class='message'>${answer.messages[i].message}</div>`;
            }

            document.getElementById('messages').innerHTML = str;
        }
    )();
}